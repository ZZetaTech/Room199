/*global console*/
// eslint-disable-line no-console
function refreshTime(){
  const timeDisplay = document.getElementById("time");
  const dateString = new Date().toLocaleString();
  const formattedString = dateString.replace(", ", " - ");
  document.getElementById("time").innerHTML = formattedString;
  console.log(timeDisplay.textContent);
  console.log("good");
}

setInterval(refreshTime, 1000);