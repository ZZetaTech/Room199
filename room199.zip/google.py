import os
from flask import Flask, redirect, url_for
from flask_dance.contrib.google import make_google_blueprint, google
import pprint
import random

app = Flask(__name__)

pprint.pprint(os.environ)

# app.secret_key = os.environ.get("FLASK_SECRET_KEY", "supersekrit")
app.secret_key = random.randint(0, 999999999)

app.config["GOOGLE_OAUTH_CLIENT_ID"] = os.environ.get("GOOGLE_OAUTH_CLIENT_ID")
app.config["GOOGLE_OAUTH_CLIENT_SECRET"] = os.environ.get(
    "GOOGLE_OAUTH_CLIENT_SECRET")

google_bp = make_google_blueprint(scope=["profile", "email"])
app.register_blueprint(google_bp, url_prefix="/login")


@app.route("/")
def index():
    if not google.authorized:
        return redirect(url_for("google.login"))
    resp = google.get("/oauth2/v1/userinfo")
    assert resp.ok, resp.text
    return "You are {email} on Google".format(email=resp.json()["email"])
